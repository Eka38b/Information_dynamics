# Draft005 revised manuscript and response

The review bundle contains the revised manuscript PDF, the revised response PDF,
the original manuscript and referee report for comparison, and `texfiles.zip`.

## LaTeX sources

- `main.tex`: revised manuscript.
- `response.tex`: revised point-by-point response.
- `comnet.cls`, `comnet.bst`, `mybib.bib`: supplied journal class, bibliography
  style, and bibliography database.
- `main.bbl`: generated bibliography included for convenient submission.
- `copy_cycle.pdf`, `local_hyperarcs.pdf`: figure assets already included.
- `create_figures.py`: optional regeneration of the figure assets with Matplotlib.
- `verify_examples.py`: complete finite-ensemble checks of the examples.
- `REVISION_NOTES.md`: record of the mathematical and language changes.
- `verification_results.txt`: results of the finite checks and PDF validation.

## Build

Use a standard LaTeX installation with the packages required by `comnet.cls`
(including AMS packages, graphics, natbib, and ulem) and the geometry package
for the response letter.

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error response.tex
```

The figure PDFs are ready to use. Regenerating them is optional:

```sh
python3 create_figures.py
```

The example checks use Python's standard library:

```sh
python3 verify_examples.py
```

The journal class and bibliography style have been retained. No journal page
dimensions or margins were changed. Forward and backward minimal neighbor sets
are defined separately; their union is used only for entropy bookkeeping.
