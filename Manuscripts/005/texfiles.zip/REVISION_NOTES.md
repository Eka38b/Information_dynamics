# Draft005 revision notes

## Applied mathematical changes

- Introduced forward-minimal neighbor sets K_A and backward-minimal neighbor sets Q_A for every nonempty target set.
- Defined direct reversed-TE hyperarcs through Q_A, replacing the filtered union definition and the earlier proposed B-set workaround.
- Retained K_A for forward directness. The combined set L_v = K_v union Q_v is used only for entropy bookkeeping.
- Derived the exact entropy balance with separate forward and backward expansions.
- Replaced the former Proposition 4.2 by local support equivalences. Added a reversible swap showing why the stronger old assertion fails.
- Restored the BF-source entropy decrease result as Corollary 4.1, alongside the BF-sink result.
- Retained the reviewer's exclusion of F-inflow without B-inflow. These cases remain impossible.
- Qualified cycle necessity by a fixed nonempty topology and assumptions holding at every step. Removed the unsupported assertion that every vertex belongs to a cycle.
- Updated the stationary entropy condition to require both B-inflow and F-outflow, plus numerical aggregate balance.
- Replaced the incomplete copying discussion with a closed three-node copying cycle, added a six-node reversible XOR cycle with genuine higher-order channels, and added a reversible controlled-update counterexample to blocking.
- Replaced the connectivity counterexample by a reversible four-node model without the duplicated-variable problem.
- Corrected the conditioning-expansion signs in Appendices A and B.
- Added the two missing inverse-XOR TE channels and their reversed counterparts.

## Scope and presentation

- The stochastic examples remain local illustrations. No deterministic enlargement is demanded; the formerly numbered concern #4 was dropped as instructed.
- The local stochastic illustrations are not claimed to satisfy the main reversible framework or to possess all backward-neighbor sets.
- Applied the manuscript and response-letter grammar corrections.
- Replaced the mismatched inverse-map notation by a consistent global inverse map.
- Replaced the obsolete incomplete page-10 sentence within the rewritten proof.
- Added exact schematic figures and resolved all figure references.
- Corrected appendix equation and figure numbering.
- Updated the response letter to explain the definition changes and all substantive proof corrections.

## Build

Run `python3 create_figures.py` if regenerating the figures, then
`latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex` and
`latexmk -pdf -interaction=nonstopmode -halt-on-error response.tex`.
The supplied figure PDFs and main.bbl allow compilation without regenerating artwork or rerunning BibTeX when preferred.
