"""Generate the exact schematic figures used by main.tex."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Ellipse, FancyArrowPatch

ROOT = Path(__file__).resolve().parent
plt.rcParams.update({"font.family": "STIXGeneral", "mathtext.fontset": "stix", "font.size": 12, "pdf.fonttype": 42, "ps.fonttype": 42})
BLUE = "#176493"
RED = "#b44435"

def arrow(ax, start, end, color, bend=0, dashed=False, shrink=17):
    patch = FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=14,
                            connectionstyle=f"arc3,rad={bend}",
                            linewidth=1.6, color=color,
                            linestyle="--" if dashed else "-",
                            shrinkA=shrink, shrinkB=shrink)
    ax.add_patch(patch)

def cycle():
    fig, ax = plt.subplots(figsize=(4.7, 3.0))
    pos = {"u": (0, 1), "v": (1.85, 1), "w": (.925, -.48)}
    for a,b in [("u","v"),("v","w"),("w","u")]:
        arrow(ax, pos[a], pos[b], BLUE, bend=.11)
        arrow(ax, pos[b], pos[a], RED, bend=.11, dashed=True)
    for name,(x,y) in pos.items():
        ax.add_patch(Circle((x,y), .16, facecolor="white", edgecolor="#303030", linewidth=1.3, zorder=4))
        ax.text(x,y,f"${name}$",ha="center",va="center",fontsize=15,zorder=5)
    ax.set(xlim=(-.45,2.3),ylim=(-.9,1.35),aspect="equal")
    ax.axis("off")
    fig.savefig(ROOT/"copy_cycle.pdf", bbox_inches="tight", pad_inches=.04)
    plt.close(fig)

def local_channels():
    fig, axs = plt.subplots(1,2,figsize=(7.1,2.15))
    for ax in axs:
        ax.set(xlim=(-.6,2.5),ylim=(-.65,.8),aspect="equal")
        ax.axis("off")
    for ax,left,right,label in [(axs[0],r"$\{a,b\}$",r"$\{p\}$","(a) XOR: B-arc"),
                                (axs[1],r"$\{p\}$",r"$\{d,e\}$","(b) Inverse XOR: F-arc")]:
        ax.add_patch(Ellipse((0,0), .91,.62,facecolor="#f4f7f9",edgecolor="#303030",linewidth=1.1))
        ax.add_patch(Ellipse((1.9,0), .91,.62,facecolor="#f4f7f9",edgecolor="#303030",linewidth=1.1))
        ax.text(0,0,left,ha="center",va="center",fontsize=15)
        ax.text(1.9,0,right,ha="center",va="center",fontsize=15)
        arrow(ax,(.45,.1),(1.45,.1),BLUE,bend=-.19,shrink=0)
        arrow(ax,(1.45,-.1),(.45,-.1),RED,bend=-.19,dashed=True,shrink=0)
        ax.text(.95,.48,r"$-\ln 2$",ha="center",va="center",color=BLUE)
        ax.text(.95,-.45,r"$-\ln 2$",ha="center",va="center",color=RED)
        ax.text(.95,.76,label,ha="center",va="center",fontsize=12)
    fig.subplots_adjust(wspace=.14)
    fig.savefig(ROOT/"local_hyperarcs.pdf", bbox_inches="tight",pad_inches=.04)
    plt.close(fig)

if __name__ == "__main__":
    cycle()
    local_channels()
