"""Finite-ensemble checks for the examples and all their hyperarcs.

This verifies the stated examples, not the general mathematical propositions.
Information values are computed in nats from the complete finite joint laws.
"""
from collections import defaultdict
from functools import lru_cache
from itertools import product
from math import log

TOL = 1e-9

class Model:
    def __init__(self, names, samples):
        self.names = names
        self.n = len(names)
        self.full = (1 << self.n) - 1
        self.samples = samples
        assert abs(sum(p for _, p in samples)-1) < TOL
        self.K = {}
        self.Q = {}
        for a in range(1, self.full+1):
            candidates = [s for s in range(self.full+1) if not s & a]
            f = [s for s in candidates if abs(self.cond(a << self.n, a | s)) < TOL]
            b = [s for s in candidates if abs(self.cond(a, (a | s) << self.n)) < TOL]
            self.K[a] = self.minimal(f)
            self.Q[a] = self.minimal(b)

    @staticmethod
    def minimal(sets):
        return [s for s in sets if not any(t != s and not t & ~s for t in sets)]

    @lru_cache(None)
    def H(self, mask):
        law = defaultdict(float)
        for state, p in self.samples:
            law[tuple(state[j] for j in range(2*self.n) if mask >> j & 1)] += p
        return -sum(p*log(p) for p in law.values() if p)

    def cond(self, a, b):
        return self.H(a | b)-self.H(b)

    def co(self, args, cond):
        value = 0
        sub = args
        while sub:
            value += (1 if sub.bit_count() % 2 else -1)*self.cond(sub, cond)
            sub = (sub-1) & args
        return value

    def te(self, a, b):
        return self.co(a | (b << self.n), b)

    def rte(self, a, b):
        return self.co(b | (a << self.n), b << self.n)

    def supports(self):
        te = set()
        rte = set()
        for a in range(1, self.full+1):
            for b in range(1, self.full+1):
                if a & b:
                    continue
                if abs(self.te(a,b)) > TOL and any(not a & ~k for k in self.K[b]):
                    te.add((a,b))
                if abs(self.rte(a,b)) > TOL and any(not a & ~q for q in self.Q[b]):
                    rte.add((a,b))
        return te, rte

    def both_zero(self):
        for i in range(self.n):
            a = 1 << i
            assert self.K[a] and self.Q[a]
            for k in self.K[a]:
                for q in self.Q[a]:
                    both = k | q
                    alpha = self.cond(a << self.n, a | both)-self.cond(a, (a | both) << self.n)
                    assert abs(alpha) < TOL

def assert_close(a,b):
    assert abs(a-b) < TOL, (a,b)

def deterministic(names, inputs, update):
    return Model(names, [(old+tuple(update(old)), p) for old,p in inputs])

def run():
    ln2 = log(2)
    cycle = deterministic(['v','u','w'], [(s,1/8) for s in product([0,1],repeat=3)],
                          lambda s:(s[1],s[2],s[0]))
    E,R = cycle.supports()
    assert E == {(2,1),(1,4),(4,2)}
    assert R == {(b,a) for a,b in E}
    assert not E & R
    cycle.both_zero()
    for a,b in E:assert_close(cycle.te(a,b),ln2)
    print('Copying cycle: full direct supports, all values, strong blocking, and combined alpha verified.')

    higher = deterministic(['a','b','c','d','e','f'],
                           [(s,1/64) for s in product([0,1],repeat=6)],
                           lambda s:(s[4],s[5],s[0],s[0]^s[1],s[2],s[3]))
    E,R = higher.supports()
    expected = {(1,4):ln2,(4,16):ln2,(8,32):ln2,(16,1):ln2,(32,2):ln2,
                (3,8):-ln2,(2,12):-ln2,(3,12):-ln2}
    assert E == set(expected) and R == {(b,a) for a,b in E}
    assert not E & R
    higher.both_zero()
    for (a,b),value in expected.items():
        assert_close(higher.te(a,b),value)
        assert_close(higher.rte(b,a),value)
    print('Reversible XOR cycle: complete higher-order supports, all values, and combined alpha verified.')

    swap = deterministic(['v','u'], [((0,0),.5),((1,0),.5)],lambda s:(s[1],s[0]))
    E,R=swap.supports()
    assert E == {(1,2)} and R == {(2,1)}
    swap.both_zero()
    assert_close(swap.H(1 << 2)-swap.H(1),-ln2)
    assert_close(swap.H(2 << 2)-swap.H(2),ln2)
    print('Reversible swap: source/sink counterexample and entropy signs verified.')

    control=deterministic(['u','v'],[(s,.25) for s in product([0,1],repeat=2)],
                          lambda s:(s[0],s[0]^s[1]))
    E,R=control.supports()
    assert E == {(1,2)} and R == E
    control.both_zero()
    print('Controlled update: reversible but blocking fails, as stated.')

    inputs=[]
    for c,d,z in product([0,1],repeat=3):
        inputs.append(((0,c,c^z,d),(.25 if z else .75)/4))
    conn=deterministic(['X','C','Y','D'],inputs,lambda s:(s[1],s[0],s[2]^s[3],s[3]))
    E,R=conn.supports()
    assert E == {(2,1),(8,4)}
    h=-.25*log(.25)-.75*log(.75)
    assert_close(conn.te(4,1),ln2-h)
    assert_close(conn.te(6,1),ln2-h)
    conn.both_zero()
    print('Connectivity counterexample: all target/source sets enumerated; direct and indirect claims verified.')

    samples=[]
    for a,b,p,aa,bb in product([0,1],repeat=5):
        samples.append(((a,b,p,aa,bb,a^b),1/32))
    xor=Model(['a','b','p'],samples)
    assert_close(xor.te(3,4),-ln2)
    assert_close(xor.rte(4,3),-ln2)
    alpha=xor.cond(4 << 3,4|3)-xor.cond(4,(4|3) << 3)
    assert_close(alpha,-ln2)
    print('Local XOR: higher-order values and nonzero residual verified.')

    samples=[]
    for p,z,d,e,pp,zz in product([0,1],repeat=6):
        samples.append(((p,z,d,e,pp,zz,z,z^(1-p)),1/64))
    inv=Model(['p','zeta','d','e'],samples)
    expected={(2,4):ln2,(3,8):-ln2,(1,12):-ln2,(3,12):-ln2}
    E,_=inv.supports()
    assert E == set(expected)
    for (a,b),value in expected.items():
        assert_close(inv.te(a,b),value)
        assert_close(inv.rte(b,a),value)
    rawR={(a,b) for a in range(1,16) for b in range(1,16)
          if not a&b and abs(inv.rte(a,b))>TOL}
    assert rawR == {(b,a) for a,b in expected}
    print('Local inverse XOR: complete four-channel TE list and all reversed values verified.')

if __name__=='__main__':
    run()
