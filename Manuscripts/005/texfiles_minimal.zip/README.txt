Draft005: minimal revision

This version starts from the author-supplied LaTeX source, rather than the broader rewrite.
All section and subsection titles are unchanged. No figures are included.
Edits address the forward/backward neighbor definitions, entropy expansion,
strong blocking, the affected propositions and proofs, and the agreed corrections.

The ZIP contains both PDFs and texfiles_minimal.zip.
To compile the source, run:
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error response.tex

The supplied journal class, bibliography style, and bibliography are unchanged.
